wp-shell-plugin
===============

WpShellPlugin is script for upload shell on Wordpress site if you have Dashboard access.
Just need to upload plugin from your Computer and install it (YOU CAN'T ACTIVATE IT). It will be uploaded to 
http://site/wp-content/plugins/<pluginname>
